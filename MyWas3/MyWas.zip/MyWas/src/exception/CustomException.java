package exception;

public class CustomException {
    
}
