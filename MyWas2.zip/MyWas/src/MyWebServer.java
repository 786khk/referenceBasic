public class MyWebServer {
    public String request(String uri) {
        Pages pages = new Pages();
        Interceptors interceptors = new Interceptors();
        HttpRequest httpRequest = new HttpRequest(uri);

        Config config = new Config();
        config.loadInterceptors(interceptors);
        
        String page;

        if(interceptors.preHandle(httpRequest)) {
            page = pages.renderPage(httpRequest);

            interceptors.postHandle(httpRequest);
            //view 랜더링
            interceptors.afterCompletion(httpRequest);
        } else {
            page = pages.renderPage("404.html");
        }

        return page;
    }  
}
