public class Config {
    public void loadInterceptors(Interceptors interceptors) {
        interceptors.add(new ResourceRenameInterceptor());
    }    
}
