package 연습;

public interface IReq {
    public void receiveReq(String url);
}
