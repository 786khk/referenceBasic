package 연습;
// 인터페이스 핸들러의 구현체 DefaultInterceptor
public class InterCeptorHandler implements HandlerInterceptor{
    //사용자의 요청에 대한 정의
    @Override
    public boolean preHandler(HttpRequest httpRequest) {

        String urlArray[] = httpRequest.getSrc().split("=");
        String param = urlArray[1];
        String path = urlArray[0]; 

        return (!param.equals(null)&& !path.equals(null))? true :false;
    }

    @Override
    public void postHandler(HttpRequest httpRequest) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void afterHandler(HttpRequest httpRequest) {
        // TODO Auto-generated method stub
        
    }
    


}
