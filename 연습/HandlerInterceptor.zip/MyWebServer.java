package 연습;

public class MyWebServer {
    public String request(String url){
        HandlerInterceptor handlerInterceptor = new InterCeptorHandler();
        HttpRequest httpRequest = new HttpRequest(url);
        if(handlerInterceptor.preHandler(httpRequest)){
            // 결과를 처리한 후 리넡을 받거나 참조로 처리한다.
            
        }
        return url;
    }
    
    



    
}
